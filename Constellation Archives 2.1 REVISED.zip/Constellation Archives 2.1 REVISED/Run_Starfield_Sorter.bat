:: READ ME: The folder I'm asking for is wherever you installed Mod Organizer 2 SO... 
:: (default dir or custom location\ModOrganizer\YOUR NAMED FOLDER HERE)

set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

@echo off

echo ===================================================
echo   Starfield MO2 Mod Scanner, Conflict Checker ^& Sorter   
echo ===================================================
echo.

:: Execute PowerShell script passing current directory
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%Sort_Starfield_Mods.ps1" -WorkingDir "%SCRIPT_DIR:~0,-1%"

echo.
echo ===================================================
echo Process complete. Press any key to exit.
echo ===================================================
pause >nul