Copyright (c) \[2026] \[kimmidontcare]



All rights reserved.



This software and associated mod files (the "Constellation Archive") are released for Early Access 

on GitHub and soon to be Nexus Mods (hopefully). By downloading, viewing, or using this Content, you agree to the following terms:



1\. NO REDISTRIBUTION: You may not redistribute, re-upload, host, or mirror this Content, 

&#x20;  in whole or in part, on any other website, platform, or file-sharing service (including 

&#x20;  Nexus Mods, ModDB, Patreon, Discord, or public cloud storage) without explicit, written 

&#x20;  permission from the author.

2\. NO COMMERCIAL USE: This Content, or any portion of it, may not be used in any 

&#x20;  monetized or commercial context, including behind paywalls (Patreon early access, 

&#x20;  sub-only downloads), YouTube/Twitch monetization tied directly to exclusive access, 

&#x20;  or bundled with paid products.

3\. ASSET USAGE \& PORTS: You may not extract assets (textures, meshes, scripts, data files) 

&#x20;  from this mod to use in other projects, nor port this mod to other games or platforms, 

&#x20;  without explicit prior permission.

4\. MODPACKS / COLLECTIONS: Inclusion in modpacks, custom installers, or automated 

&#x20;  mod collection lists (such as Wabbajack or Vortex collections) is permitted only 

&#x20;  if the collection links directly back to the official GitHub repository and does 

&#x20;  not repackage or host the files locally.

5\. "AS IS" WARRANTY: This Content is provided "as is", without warranty of any kind, 

&#x20;  express or implied. The author is not responsible for any save file corruption, game 

&#x20;  crashes, or PC issues arising from the use of this mod.

