param (
    [string]$WorkingDir = $PSScriptRoot,
    [string]$ApiKey     = "" # Optional: Enter Nexus Mods API Key
)


# 1. Automatically switch to Full Screen mode
$Wshell = New-Object -ComObject WScript.Shell
$Wshell.SendKeys("{F11}")



Clear-Host

Write-Host "_________                         __         .__  .__          __  .__                   _____                .__    .__                     
\_   ___ \  ____   ____   _______/  |_  ____ |  | |  | _____ _/  |_|__| ____   ____     /  _  \_______   ____ |  |__ |__|__  __ ____   ______
/    \  \/ /  _ \ /    \ /  ___/\   __\/ __ \|  | |  | \__  \\   __\  |/  _ \ /    \   /  /_\  \_  __ \_/ ___\|  |  \|  \  \/ // __ \ /  ___/
\     \___(  <_> )   |  \\___ \  |  | \  ___/|  |_|  |__/ __ \|  | |  (  <_> )   |  \ /    |    \  | \/\  \___|   Y  \  |\   /\  ___/ \___ \ 
 \______  /\____/|___|  /____  > |__|  \___  >____/____(____  /__| |__|\____/|___|  / \____|__  /__|    \___  >___|  /__| \_/  \___  >____  >
        \/            \/     \/            \/               \/                    \/          \/            \/     \/              \/     \/ " -ForegroundColor Blue



Write-Host "    _       _           ___          _             ___              _        
   /_\ _  _| |_ ___ ___/ __| ___ _ _| |_ ___ _ _  / __| ___ _ ___ _(_)__ ___ 
  / _ \ || |  _/ _ \___\__ \/ _ \ '_|  _/ -_) '_| \__ \/ -_) '_\ V / / _/ -_)
 /_/ \_\_,_|\__\___/   |___/\___/_|  \__\___|_|   |___/\___|_|  \_/|_\__\___|
                                                                             " -ForegroundColor Green



Write-Host @"
===================================================
  Starfield MO2 Mod Auto Sorter, Conflict Checker & Sorter
===================================================

 _____________________
< Don't forget Roach Race CDPR! (Just a nod to my fav game!!) >
 ---------------------
        \   ^__^
         \  (oo)\_______
            (__)\       )\/\
                ||----w |
                ||     ||
"@ -ForegroundColor DarkGreen

Write-Host "Remember, logs won't show up in the Constellation Archives folder unless you back out, then go back in" -ForegroundColor Red

# ----------------------------------------------------
# Local Database Setup (.db file handling)
# ----------------------------------------------------
$DbFilePath = Join-Path -Path $WorkingDir -ChildPath "mod_database.db"

function Initialize-LocalDatabase {
    param ([string]$Path)
    if (-not (Test-Path $Path)) {
        "ModID,Category" | Out-File -FilePath $Path -Encoding utf8
    }
}

function Get-CachedCategory {
    param ([int]$ModId, [string]$Path)
    if (-not (Test-Path $Path) -or $ModId -le 0) { return $null }
    $lines = Get-Content -Path $Path
    foreach ($line in $lines) {
        $parts = $line.Split(",")
        if ($parts.Count -ge 2 -and $parts[0].Trim() -eq $ModId.ToString()) {
            return $parts[1].Trim()
        }
    }
    return $null
}

function Set-CachedCategory {
    param ([int]$ModId, [string]$Category, [string]$Path)
    if ($ModId -le 0 -or [string]::IsNullOrWhiteSpace($Category)) { return }
    if (Test-Path $Path) {
        $existing = Get-CachedCategory -ModId $ModId -Path $Path
        if (-not $existing) {
            "$ModId,$Category" | Out-File -FilePath $Path -Append -Encoding utf8
        }
    }
}

Initialize-LocalDatabase -Path $DbFilePath

# Optional Nexus API Lookup Function
function Get-NexusModInfo {
    param ([int]$ModId, [string]$Key)
    if ([string]::IsNullOrEmpty($Key) -or $ModId -le 0) { return $null }
    $headers = @{ "apikey" = $Key; "accept" = "application/json" }
    try {
        return Invoke-RestMethod -Uri "https://api.nexusmods.com/v1/games/starfield/mods/$ModId.json" -Headers $headers -Method Get
    } catch {
        return $null
    }
}

# ----------------------------------------------------
# 0. Deep Analysis & Extended Feature Prompt
# ----------------------------------------------------
Write-Host "`n# ----------------------------------------------------" -ForegroundColor DarkGreen
Write-Host "# Extra Feature Prompt: Extended Sorting Logic" -ForegroundColor Blue
Write-Host "# ----------------------------------------------------" -ForegroundColor DarkGreen

Write-Host "Would you like to run Deep Analysis sorting (checks categories, dependencies, and file conflicts to make sorting more accurate)?" -ForegroundColor Yellow
Write-Host "[1] Um..DUH!!" -ForegroundColor Green
Write-Host "[2] I'd rather not, just use standard method (less accurate.." -ForegroundColor Red

$sortingChoice = Read-Host "`nChoice (1 or 2)"

if ($sortingChoice -eq "1" -or $sortingChoice -match "DUH") {
    Write-Host "`n[+] Engaging Deep Analysis & Smart Category Sorting..." -ForegroundColor Green
    $EnableDeepAnalysis = $true

    if ([string]::IsNullOrWhiteSpace($ApiKey)) {
        Write-Host "`nTo query Nexus Mods for deep category info and requirements:" -ForegroundColor Cyan
        $userApiKey = Read-Host "Please paste your PERSONAL Nexus Mods API Key (or press Enter to skip API checks)"

        if (-not [string]::IsNullOrWhiteSpace($userApiKey)) {
            $ApiKey = $userApiKey.Trim()
            Write-Host "  [OK] Nexus API Key saved for this session." -ForegroundColor Green
        } else {
            Write-Host "  [!] No key provided. Checking local .db cache & file heuristics." -ForegroundColor Red
        }
    }
} else {
    Write-Host "`n[-] Bypassing extended checks. Running standard sorting method..." -ForegroundColor Gray
    $EnableDeepAnalysis = $false
}

# ----------------------------------------------------
# Initialization & Working Directory Setup
# ----------------------------------------------------
if (-not (Test-Path -Path $WorkingDir)) {
    $WorkingDir = $PSScriptRoot
}

$InstalledModsLog   = Join-Path -Path $WorkingDir -ChildPath "installed mods list.txt"
$LooseFilesLog      = Join-Path -Path $WorkingDir -ChildPath "loose files mods sorted.txt"
$LoadOrderBeforeLog = Join-Path -Path $WorkingDir -ChildPath "load order before.txt"
$LoadOrderAfterLog  = Join-Path -Path $WorkingDir -ChildPath "load order after.txt"
$ConflictReportLog  = Join-Path -Path $WorkingDir -ChildPath "conflict analysis report.txt"

Write-Host "`n[1/8] Instantly locating MO2 AppData profiles..." -ForegroundColor Cyan

$ProfilePath = $null
$InstanceRoot = $null
$ProfileBasePath = $null

# 1. Quick Instant Check of Common AppData Paths
$PotentialAppDataProfiles = @(
    "$env:APPDATA\ModOrganizer\Starfield\profiles",
    "$env:LOCALAPPDATA\ModOrganizer\Starfield\profiles",
    "$env:APPDATA\ModOrganizer\Common\Starfield\profiles",
    "$env:LOCALAPPDATA\ModOrganizer\Common\Starfield\profiles"
)

foreach ($path in $PotentialAppDataProfiles) {
    if (Test-Path $path) {
        $ProfileBasePath = $path
        $InstanceRoot = (Get-Item (Join-Path $ProfileBasePath "..")).FullName
        Write-Host "  [OK] Found AppData instance: $InstanceRoot" -ForegroundColor Green
        break
    }
}

# 2. If standard paths miss, check if user has ModOrganizer folder directly in AppData and look for Starfield subfolders quickly
if (-not $ProfileBasePath) {
    foreach ($baseDir in @("$env:APPDATA\ModOrganizer", "$env:LOCALAPPDATA\ModOrganizer")) {
        if (Test-Path $baseDir) {
            $subFolders = Get-ChildItem -Path $baseDir -Directory -ErrorAction SilentlyContinue
            foreach ($sub in $subFolders) {
                $checkProfilePath = Join-Path $sub.FullName "profiles"
                if (Test-Path $checkProfilePath) {
                    $ProfileBasePath = $checkProfilePath
                    $InstanceRoot = $sub.FullName
                    Write-Host "  [OK] Located instance under: $InstanceRoot" -ForegroundColor Green
                    break
                }
            }
        }
        if ($ProfileBasePath) { break }
    }
}

# 3. Resolve active Starfield profile folder
if ($ProfileBasePath -and (Test-Path $ProfileBasePath)) {
    $profiles = Get-ChildItem -Path $ProfileBasePath -Directory -ErrorAction SilentlyContinue
    if ($profiles) {
        $starfieldProfile = $profiles | Where-Object { $_.Name -match "Starfield|Default" } | Select-Object -First 1
        if ($starfieldProfile) {
            $ProfilePath = $starfieldProfile.FullName
        } else {
            $ProfilePath = ($profiles | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName
        }
    }
}

# Fast manual fallback so it never hangs
if (-not $ProfilePath -or -not (Test-Path $ProfilePath)) {
    Write-Host "Could not automatically locate your AppData MO2 Starfield profile folder instantly." -ForegroundColor Yellow
    $UserPath = Read-Host "Please paste the full path to your AppData Starfield profile folder (e.g., C:\Users\...\AppData\Local\ModOrganizer\Starfield\profiles\Default)"
    if (Test-Path $UserPath) {
        $ProfilePath = $UserPath
        $InstanceRoot = (Get-Item (Join-Path $ProfilePath "..")).FullName
    } else {
        Write-Host "Error: Path not found. Exiting." -ForegroundColor Red
        exit
    }
}

# Determine Mods Directory
$ModsDir = Join-Path -Path $InstanceRoot -ChildPath "mods"
if (-not (Test-Path $ModsDir)) {
    $ParentOfInstance = (Get-Item (Join-Path $InstanceRoot "..")).FullName
    if (Test-Path (Join-Path $ParentOfInstance "mods")) {
        $ModsDir = Join-Path $ParentOfInstance "mods"
    } else {
        $UserModsDir = Read-Host "Enter the path to your MO2 'mods' folder (where individual mod folders are stored)"
        if (Test-Path $UserModsDir) {
            $ModsDir = $UserModsDir
        }
    }
}

# Locate Main Game Directory / Script Extender
$GameDir = $null
$PossibleGamePaths = @(
    "C:\Program Files (x86)\Steam\steamapps\common\Starfield",
    "C:\Steam\steamapps\common\Starfield",
    "D:\Steam\steamapps\common\Starfield",
    "C:\XboxGames\Starfield\Content"
)

foreach ($gPath in $PossibleGamePaths) {
    if (Test-Path (Join-Path $gPath "Starfield.exe")) {
        $GameDir = $gPath
        break
    }
}

if (-not $GameDir) {
    $UserGameDir = Read-Host "Enter your main Starfield game directory path (where Starfield.exe & sfse_loader.exe are located)"
    if (Test-Path $UserGameDir) {
        $GameDir = $UserGameDir
    }
}

Write-Host "Profile Directory: $ProfilePath" -ForegroundColor Green
Write-Host "Mods Directory:    $ModsDir" -ForegroundColor Green
if ($GameDir) {
    Write-Host "Game Directory:    $GameDir" -ForegroundColor Green
} else {
    Write-Host "Game Directory:    [Not Found automatically]" -ForegroundColor Yellow
}

# ----------------------------------------------------
# 1. Parse Profile status (modlist.txt)
# ----------------------------------------------------
$ModListFile = Join-Path -Path $ProfilePath -ChildPath "modlist.txt"
$ModStatusMap = @{}

if (Test-Path $ModListFile) {
    Get-Content -Path $ModListFile | ForEach-Object {
        $line = $_.Trim()
        if ($line.StartsWith("+")) {
            $ModStatusMap[$line.Substring(1)] = "ENABLED"
        } elseif ($line.StartsWith("-")) {
            $ModStatusMap[$line.Substring(1)] = "DISABLED"
        }
    }
}

# ----------------------------------------------------
# 2. Categorize & Scan Mods with Live Counter & DB Check
# ----------------------------------------------------
Write-Host "[2/8] Scanning MO2 'mods' folder (with Live Counter & Database lookup)..." -ForegroundColor Blue

$InstalledModOutput = @()
$EnabledModFolders  = @()
$LooseFileMods      = @()
$PluginMods         = @()
$PluginCategoryMap  = @{} 

$totalModsFound     = 0
$scannedCount       = 0
$hasStarUI          = $false
$hasFreeLanesPatch  = $false

if (Test-Path $ModsDir) {
    $DiskModFolders = @(Get-ChildItem -Path $ModsDir -Directory)
    $totalModsFound = $DiskModFolders.Count
    
    foreach ($folder in $DiskModFolders) {
        $scannedCount++
        $name   = $folder.Name
        
        # Check for StarUI presence
        if ($name -match "StarUI") {
            $hasStarUI = $true
            if ($name -match "Free Lanes Compatibility Patch") {
                $hasFreeLanesPatch = $true
            }
        }

        $status = if ($ModStatusMap.ContainsKey($name)) { $ModStatusMap[$name] } else { "UNTRACKED" }
        $prefix = if ($status -eq "ENABLED") { "+" } else { "-" }

        Write-Progress -Activity "Scanning Installed Mods" -Status "Processing: $name" -PercentComplete (($scannedCount / $totalModsFound) * 100)

        $InstalledModOutput += "[$status] $name"
        if ($status -eq "ENABLED") {
            $EnabledModFolders += $folder.FullName
        }

        $nexusCategory = ""
        $metaFile = Join-Path -Path $folder.FullName -ChildPath "meta.ini"
        if (Test-Path $metaFile) {
            $modIdLine = Get-Content -Path $metaFile | Where-Object { $_ -like "modid=*" }
            if ($modIdLine) {
                [int]$modId = $modIdLine.Split("=")[1].Trim()
                if ($modId -gt 0) {
                    $nexusCategory = Get-CachedCategory -ModId $modId -Path $DbFilePath
                    
                    if ([string]::IsNullOrEmpty($nexusCategory) -and $EnableDeepAnalysis -and -not [string]::IsNullOrWhiteSpace($ApiKey)) {
                        Write-Host "  [API] Querying Nexus for $name (ID: $modId)..." -ForegroundColor DarkGray
                        $nexusData = Get-NexusModInfo -ModId $modId -Key $ApiKey
                        if ($nexusData -and $nexusData.category) {
                            $nexusCategory = $nexusData.category
                            Set-CachedCategory -ModId $modId -Category $nexusCategory -Path $DbFilePath
                        }
                        Start-Sleep -Milliseconds 200
                    }
                }
            }
        }

        $pluginsInMod = Get-ChildItem -Path "$($folder.FullName)\*" -Include *.esm, *.esp, *.esl -Recurse -ErrorAction SilentlyContinue
        $hasPlugin = ($pluginsInMod.Count -gt 0)

        foreach ($plug in $pluginsInMod) {
            $PluginCategoryMap[$plug.Name] = $nexusCategory
        }

        $modObj = [PSCustomObject]@{
            Name          = $name
            Status        = $status
            Prefix        = $prefix
            Path          = $folder.FullName
            NexusCategory = $nexusCategory
        }

        if ($hasPlugin) {
            $PluginMods += $modObj
        } else {
            $LooseFileMods += $modObj
        }
    }
    Write-Progress -Activity "Scanning Installed Mods" -Completed
} else {
    Write-Host "Warning: Could not locate 'mods' directory at $ModsDir" -ForegroundColor Red
}

# StarUI & Patch Validation Notice
if ($hasStarUI) {
    Write-Host "  [OK] StarUI mod(s) detected." -ForegroundColor Green
    if ($hasFreeLanesPatch) {
        Write-Host "  [OK] StarUI Inventory - Free Lanes Compatibility Patch detected." -ForegroundColor Green
    } else {
        Write-Host "  [!] Warning: StarUI detected, but 'StarUI Inventory - Free Lanes Compatibility Patch' was not found. Menu SWF files may break on the newest game version!" -ForegroundColor Yellow
    }
}

Write-Host "  [OK] Scan complete! Found $totalModsFound total mods ($($PluginMods.Count) plugin mods, $($LooseFileMods.Count) loose file mods)." -ForegroundColor Green
$InstalledModOutput | Out-File -FilePath $InstalledModsLog -Encoding utf8

$SortedLooseMods = $LooseFileMods | Sort-Object Name
$LooseFileOutput = $SortedLooseMods | ForEach-Object { "[$($_.Status)] $($_.Name)" }
$LooseFileOutput | Out-File -FilePath $LooseFilesLog -Encoding utf8

# ----------------------------------------------------
# 3. Conflict Detection Engine (File Overlaps)
# ----------------------------------------------------
if ($EnableDeepAnalysis) {
    Write-Host "[3/8] Running Conflict Analysis across enabled mods..." -ForegroundColor Blue

    $FileMap = @{}
    $ConflictList = @()

    foreach ($modPath in $EnabledModFolders) {
        $modName = Split-Path $modPath -Leaf
        $files = Get-ChildItem -Path $modPath -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -notlike "*.meta" }

        foreach ($file in $files) {
            $relativePath = $file.FullName.Substring($modPath.Length)
            if (-not $FileMap.ContainsKey($relativePath)) {
                $FileMap[$relativePath] = [System.Collections.Generic.List[string]]::new()
            }
            $FileMap[$relativePath].Add($modName)
        }
    }

    foreach ($entry in $FileMap.GetEnumerator()) {
        if ($entry.Value.Count -gt 1) {
            $isStarUIPatchConflict = $false
            if ($entry.Key -match "\.swf$" -and ($entry.Value -contains "StarUI Inventory") -and ($entry.Value -contains "StarUI Inventory - Free Lanes Compatibility Patch")) {
                $isStarUIPatchConflict = $true
            }

            $conflictLine = "File: $($entry.Key)"
            if ($isStarUIPatchConflict) {
                $conflictLine += " [EXPECTED PATCH OVERRIDE]"
            }
            $ConflictList += $conflictLine
            $ConflictList += "  Overridden by: " + ($entry.Value -join " <--- ")
        }
    }

    # Append Possible Fixes & Recommendations to Conflict Report
    if ($ConflictList.Count -gt 0) {
        $ConflictList += ""
        $ConflictList += "========================================================="
        $ConflictList += "           POSSIBLE FIXES & RECOMMENDATIONS"
        $ConflictList += "========================================================="
        $ConflictList += "1. UI / SWF Menu Conflicts (StarUI & Patches):"
        $ConflictList += "   - It is NORMAL and REQUIRED for compatibility patches (like Free Lanes)"
        $ConflictList += "     to override base UI mods (like StarUI Inventory) so they work on newer game updates."
        $ConflictList += "   - Ensure your compatibility patch is placed *lower* (further down) in your MO2 left panel"
        $ConflictList += "     than the base StarUI mod so it properly applies the override."
        $ConflictList += ""
        $ConflictList += "2. General Loose File Overrides:"
        $ConflictList += "   - If an unintended mod is overriding another, drag and drop the mod folders"
        $ConflictList += "     in your MO2 left pane to adjust priority, or hide specific conflicting files."
        
        $ConflictList | Out-File -FilePath $ConflictReportLog -Encoding utf8
        Write-Host "  [!] Conflicts detected! Report with recommended fixes saved to: $ConflictReportLog" -ForegroundColor Yellow
    } else {
        Write-Host "  [OK] No file overwrite conflicts found." -ForegroundColor Green
    }
} else {
    Write-Host "[3/8] Standard Mode: Skipping File Conflict Analysis..." -ForegroundColor Gray
}

# ----------------------------------------------------
# 4. Dependency & Script Extender Check (Main Directory)
# ----------------------------------------------------
Write-Host "[4/8] Checking Script Extender & Core Dependencies in Main Game Directory..." -ForegroundColor Blue

$SFSEFound = $false
if ($GameDir -and (Test-Path (Join-Path $GameDir "sfse_loader.exe"))) {
    $SFSEFound = $true
    Write-Host "  [OK] Starfield Script Extender (sfse_loader.exe) verified in game root: $GameDir" -ForegroundColor Green
} else {
    $CheckSfse = Get-ChildItem -Path $ModsDir -Filter "sfse_loader.exe" -Recurse -ErrorAction SilentlyContinue
    if ($CheckSfse) {
        Write-Host "  [!] Warning: sfse_loader.exe found inside a mod folder, but it MUST be installed directly in your main Starfield game directory!" -ForegroundColor Red
    } else {
        Write-Host "  [WARNING] sfse_loader.exe not detected in main game directory ($GameDir). Script Extender plugins may fail to load." -ForegroundColor Red
    }
}

if ($EnableDeepAnalysis) {
    $InstalledModNames = $PluginMods.Name + $LooseFileMods.Name
    $MissingDeps = @()
    $FrameworkRules = @{
        "Address Library"  = "*Address*Library*"
        "StarUI"           = "*StarUI*"
    }

    foreach ($depName in $FrameworkRules.Keys) {
        $pattern = $FrameworkRules[$depName]
        $found = $InstalledModNames | Where-Object { $_ -like $pattern }
        if (-not $found) {
            $MissingDeps += "Missing recommended framework: $depName"
        }
    }

    foreach ($dep in $MissingDeps) {
        Write-Host "  [WARNING] $dep" -ForegroundColor Yellow
    }
}

# ----------------------------------------------------
# 5. Update MO2 Left Panel (modlist.txt) - PRESERVING User Layout & StarUI Patch Order
# ----------------------------------------------------
Write-Host "[5/8] Validating and updating MO2 left panel order..." -ForegroundColor Blue

$ExistingModListLines = @()
if (Test-Path $ModListFile) {
    $ExistingModListLines = Get-Content -Path $ModListFile
}

$FullModListOrder = New-Object 'System.Collections.Generic.List[PSCustomObject]'
foreach ($line in $ExistingModListLines) {
    if ($line.Length -gt 1) {
        $prefix = $line.Substring(0, 1)
        $modName = $line.Substring(1)
        $status = if ($prefix -eq "+") { "ENABLED" } else { "DISABLED" }
        
        $FullModListOrder.Add([PSCustomObject]@{
            Name   = $modName
            Prefix = $prefix
            Status = $status
        })
    }
}

# Ensure any newly added mods on disk that aren't in modlist.txt yet get appended safely
$ExistingNames = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
foreach ($item in $FullModListOrder) { [void]$ExistingNames.Add($item.Name) }

foreach ($folder in $DiskModFolders) {
    if (-not $ExistingNames.Contains($folder.Name)) {
        $status = if ($ModStatusMap.ContainsKey($folder.Name)) { $ModStatusMap[$folder.Name] } else { "ENABLED" }
        $prefix = if ($status -eq "ENABLED") { "+" } else { "-" }
        $FullModListOrder.Add([PSCustomObject]@{
            Name   = $folder.Name
            Prefix = $prefix
            Status = $status
        })
    }
}

# Automatic StarUI & Free Lanes Patch Order Enforcement
$starUIIndex = -1
$patchIndex = -1

for ($i = 0; $i -lt $FullModListOrder.Count; $i++) {
    $currentName = $FullModListOrder[$i].Name
    if ($currentName -eq "StarUI Inventory") {
        $starUIIndex = $i
    } elseif ($currentName -eq "StarUI Inventory - Free Lanes Compatibility Patch") {
        $patchIndex = $i
    }
}

if ($starUIIndex -ge 0 -and $patchIndex -ge 0 -and $patchIndex -lt $starUIIndex) {
    Write-Host "  [!] Fixing StarUI load order: Moving 'StarUI Inventory - Free Lanes Compatibility Patch' below base 'StarUI Inventory'..." -ForegroundColor Yellow
    $patchObj = $FullModListOrder[$patchIndex]
    $FullModListOrder.RemoveAt($patchIndex)
    
    $starUIIndex = -1
    for ($i = 0; $i -lt $FullModListOrder.Count; $i++) {
        if ($FullModListOrder[$i].Name -eq "StarUI Inventory") {
            $starUIIndex = $i
            break
        }
    }
    
    $FullModListOrder.Insert($starUIIndex + 1, $patchObj)
    Write-Host "  [OK] StarUI Free Lanes Patch successfully repositioned to override base StarUI." -ForegroundColor Green
}

$ModListLines = $FullModListOrder | ForEach-Object { "$($_.Prefix)$($_.Name)" }
$ModListLines | Out-File -FilePath $ModListFile -Encoding utf8

# ----------------------------------------------------
# 6. Read current plugins & Harvest (Strictly Enabled Only)
# ----------------------------------------------------
Write-Host "[6/8] Harvesting plugins from enabled mod folders..." -ForegroundColor Blue

$PluginsFile = Join-Path -Path $ProfilePath -ChildPath "plugins.txt"
$LoadOrderFile = Join-Path -Path $ProfilePath -ChildPath "loadorder.txt"

if (-not (Test-Path $PluginsFile)) {
    $PluginsFile = Join-Path -Path $ProfilePath -ChildPath "loadorder.txt"
}

$ExistingPlugins = @()
if (Test-Path $PluginsFile) {
    $ExistingPlugins = Get-Content -Path $PluginsFile | Where-Object { $_ -notmatch '^\s*#' -and $_.Trim() -ne '' }
}
$ExistingPlugins | Out-File -FilePath $LoadOrderBeforeLog -Encoding utf8

$DiscoveredPlugins = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)

foreach ($p in $ExistingPlugins) {
    $cleanP = $p.TrimStart('*')
    if ($cleanP) { [void]$DiscoveredPlugins.Add($cleanP) }
}

# Only harvest plugins from mods that are actually CHECKED ENABLED (+) in modlist.txt
foreach ($modItem in $FullModListOrder) {
    if ($modItem.Prefix -eq "+") {
        $targetFolder = Join-Path $ModsDir $modItem.Name
        if (Test-Path $targetFolder) {
            $pluginsInMod = Get-ChildItem -Path "$targetFolder\*" -Include *.esm, *.esp, *.esl -Recurse -ErrorAction SilentlyContinue
            foreach ($plug in $pluginsInMod) {
                [void]$DiscoveredPlugins.Add($plug.Name)
            }
        }
    }
}

# ----------------------------------------------------
# 7. Categorized Smart Sorting Engine (Database Powered)
# ----------------------------------------------------
Write-Host "[7/8] Applying Priority Category Sorting using Local DB & Metadata..." -ForegroundColor Blue

$BaseGameMasters = @("Starfield.esm", "Constellation.esm", "OldMars.esm", "ShatteredSpace.esm")
$CommunityFrameworks = @("StarfieldCommunityPatch.esm")

$SortedBase       = @()
$SortedFrameworks = @()
$SortedUI         = @()
$SortedOtherESM   = @()
$SortedESP        = @()
$SortedPatches    = @()

foreach ($plugin in $DiscoveredPlugins) {
    $cat = if ($PluginCategoryMap.ContainsKey($plugin)) { $PluginCategoryMap[$plugin] } else { "" }

    if ($BaseGameMasters -contains $plugin) {
        # Base game strictly prioritized
    } elseif ($CommunityFrameworks -contains $plugin) {
        $SortedFrameworks += $plugin
    } elseif ($cat -match "User Interface|UI|HUD" -or $plugin -like "*UI*" -or $plugin -like "*HUD*") {
        $SortedUI += $plugin
    } elseif ($cat -match "Bug Fixes|Patches" -or $plugin -like "*Patch*" -or $plugin -like "*Fix*") {
        $SortedPatches += $plugin
    } elseif ($plugin.EndsWith(".esm", [System.StringComparison]::OrdinalIgnoreCase)) {
        $SortedOtherESM += $plugin
    } else {
        $SortedESP += $plugin
    }
}

foreach ($bm in $BaseGameMasters) {
    if ($DiscoveredPlugins.Contains($bm)) { $SortedBase += $bm }
}

$FullSortedList = $SortedBase + $SortedFrameworks + ($SortedUI | Sort-Object) + ($SortedOtherESM | Sort-Object) + ($SortedESP | Sort-Object) + ($SortedPatches | Sort-Object)
$FormattedLoadOrder = $FullSortedList | ForEach-Object { "*$_" }

# ----------------------------------------------------
# 8. Output Logs & Apply Plugins to MO2
# ----------------------------------------------------
Write-Host "[8/8] Writing updated plugin load order to MO2 profile..." -ForegroundColor Blue

$FormattedLoadOrder | Out-File -FilePath $LoadOrderAfterLog -Encoding utf8

$FormattedLoadOrder | Out-File -FilePath $PluginsFile -Encoding utf8
if (Test-Path $LoadOrderFile) {
    $FormattedLoadOrder | Out-File -FilePath $LoadOrderFile -Encoding utf8
} else {
    $FormattedLoadOrder | Out-File -FilePath (Join-Path -Path $ProfilePath -ChildPath "loadorder.txt") -Encoding utf8
}

Write-Host "Successfully updated plugins.txt, loadorder.txt, and modlist.txt instantly!" -ForegroundColor Green

# Display formatted Cyberpunk text
Write-Host "`nI also made a sorter for..." -ForegroundColor Blue
Write-Host "Cyberpunk 2077(Sorts with any mod loader)," -ForegroundColor Yellow
Write-Host "The Witcher 3 (Uses The Witcher 3 Mod Manager)," -ForegroundColor Red
Write-Host "Starfield (Uses Mod Organizer 2)," -ForegroundColor Green
Write-Host "===================================================================================================" -ForegroundColor Red
Write-Host "SCRIPTING IS STABLIZIED VIA Google Gemini Ai" -ForegroundColor Blue


# Prompt the user for input
$response = Read-Host "Would you like to see my other mods on Nexus? (Y/N)"

if ($response -eq 'Y' -or $response -eq 'y') {
    Write-Host "Fly Off!" -ForegroundColor Cyan
    Start-Sleep -Seconds 1
    Start-Process "https://www.nexusmods.com/profile/kimmidontcare"
    exit
} else {
    Write-Host "Awww, well okay...later then space cowboy..or cowgirl..or whateva, we don't judge xD" -ForegroundColor Yellow
    Start-Sleep -Seconds 2
    exit
}