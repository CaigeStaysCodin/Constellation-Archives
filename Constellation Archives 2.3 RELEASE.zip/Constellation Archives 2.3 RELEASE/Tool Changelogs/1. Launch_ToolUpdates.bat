@echo off
TITLE Constellation Archive - Update Launcher
COLOR 0A

:: Ensure script is executed from its active working directory
cd /d "%~dp0"

:: Launch the PowerShell script with ExecutionPolicy bypass
powershell -NoProfile -ExecutionPolicy Bypass -File "ToolUpdates.ps1"

pause