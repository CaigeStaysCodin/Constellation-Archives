$wshell = New-Object -ComObject WScript.Shell
$wshell.SendKeys('{F11}')

# ==============================================================================
# CONSTELLATION ARCHIVE - VERSION & FEATURE DASHBOARD
# ==============================================================================

# Starfield Terminal Color Palette Configuration
$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "Gray"
Clear-Host

# Color Helper Shortcuts
function Write-Header {
    param([string]$Text)
    Write-Host $Text -ForegroundColor DarkYellow
}

function Write-Accent {
    param([string]$Text)
    Write-Host $Text -ForegroundColor Yellow
}

function Write-Highlight {
    param([string]$Text)
    Write-Host $Text -ForegroundColor Cyan
}

function Write-Muted {
    param([string]$Text)
    Write-Host $Text -ForegroundColor DarkGray
}

function Write-Success {
    param([string]$Text)
    Write-Host $Text -ForegroundColor Green
}

function Write-Warning {
    param([string]$Text)
    Write-Host $Text -ForegroundColor Red
}

# --- ASCII Banner ---
Write-Header "

      ::::::::   ::::::::  ::::    :::  :::::::: ::::::::::: :::::::::: :::        :::            ::: ::::::::::: ::::::::::: ::::::::  ::::    :::
    :+:    :+: :+:    :+: :+:+:   :+: :+:    :+:    :+:     :+:        :+:        :+:          :+: :+:   :+:         :+:    :+:    :+: :+:+:   :+: 
   +:+        +:+    +:+ :+:+:+  +:+ +:+           +:+     +:+        +:+        +:+         +:+   +:+  +:+         +:+    +:+    +:+ :+:+:+  +:+  
  +#+        +#+    +:+ +#+ +:+ +#+ +#++:++#++    +#+     +#++:++#   +#+        +#+        +#++:++#++: +#+         +#+    +#+    +:+ +#+ +:+ +#+   
 +#+        +#+    +#+ +#+  +#+#+#        +#+    +#+     +#+        +#+        +#+        +#+     +#+ +#+         +#+    +#+    +#+ +#+  +#+#+#    
#+#    #+# #+#    #+# #+#   #+#+# #+#    #+#    #+#     #+#        #+#        #+#        #+#     #+# #+#         #+#    #+#    #+# #+#   #+#+#     
########   ########  ###    ####  ########     ###     ########## ########## ########## ###     ### ###     ########### ########  ###    ####      
          :::     :::::::::   ::::::::  :::    ::: ::::::::::: :::     ::: :::::::::: ::::::::                                                     
       :+: :+:   :+:    :+: :+:    :+: :+:    :+:     :+:     :+:     :+: :+:       :+:    :+:                                                     
     +:+   +:+  +:+    +:+ +:+        +:+    +:+     +:+     +:+     +:+ +:+       +:+                                                             
   +#++:++#++: +#++:++#:  +#+        +#++:++#++     +#+     +#+     +:+ +#++:++#  +#++:++#++                                                       
  +#+     +#+ +#+    +#+ +#+        +#+    +#+     +#+      +#+   +#+  +#+              +#+                                                        
 #+#     #+# #+#    #+# #+#    #+# #+#    #+#     #+#       #+#+#+#   #+#       #+#    #+#                                                         
###     ### ###    ###  ########  ###    ### ###########     ###     ########## ########                                                           
      ::::::::  :::    :::     :::     ::::    :::  ::::::::  :::::::::: :::        ::::::::   ::::::::   ::::::::                                 
    :+:    :+: :+:    :+:   :+: :+:   :+:+:   :+: :+:    :+: :+:        :+:       :+:    :+: :+:    :+: :+:    :+:                                 
   +:+        +:+    +:+  +:+   +:+  :+:+:+  +:+ +:+        +:+        +:+       +:+    +:+ +:+        +:+                                         
  +#+        +#++:++#++ +#++:++#++: +#+ +:+ +#+ :#:        +#++:++#   +#+       +#+    +:+ :#:        +#++:++#++                                   
 +#+        +#+    +#+ +#+     +#+ +#+  +#+#+# +#+   +#+# +#+        +#+       +#+    +#+ +#+   +#+#        +#+                                    
#+#    #+# #+#    #+# #+#     #+# #+#   #+#+# #+#    #+# #+#        #+#       #+#    #+# #+#    #+# #+#    #+#                                     
########  ###    ### ###     ### ###    ####  ########  ########## ########## ########   ########   ########                                       "-ForegroundColor Blue


Write-Header "  ___ ___  _  _ ___ _____ ___  _    _      _ _____ ___  _  _   _   ___  ___ _  _ _____   _____ "-ForegroundColor Red


Write-Header "                                                                   ver. v2.3 (Pre-Release Build)"
Write-Muted  "--------------------------------------------------------------------------------------------------"
Write-Host ""

# --- Permissions Policy ---
Write-Header "=================================================================================================="
Write-Header "                     🛑 PERMISSIONS & MOD USAGE POLICY                                            "
Write-Header "=================================================================================================="
Write-Warning " [X] Re-uploading  : Do not re-upload this mod to any other site or mirror."-ForegroundColor Red
Write-Warning " [X] Porting      : No porting to other platforms or games without direct permission."
Write-Warning " [X] Asset Use    : Do not use assets/scripts in your own mods without permission."
Write-Success " [V] Modpacks     : Allowed in mod lists/collections if linking to official GitHub."-ForegroundColor Green
Write-Warning " [X] Monetization : Strictly prohibited to put behind paywalls or for commercial gain."-ForegroundColor Red
Write-Muted  "--------------------------------------------------------------------------------------------------"
Write-Host ""

# --- Changelog Matrix ---
Write-Header "=================================================================================================="
Write-Header "

      ::::::::  :::    :::     :::     ::::    :::  ::::::::  :::::::::: :::        ::::::::   ::::::::   ::::::::                                 
    :+:    :+: :+:    :+:   :+: :+:   :+:+:   :+: :+:    :+: :+:        :+:       :+:    :+: :+:    :+: :+:    :+:                                 
   +:+        +:+    +:+  +:+   +:+  :+:+:+  +:+ +:+        +:+        +:+       +:+    +:+ +:+        +:+                                         
  +#+        +#++:++#++ +#++:++#++: +#+ +:+ +#+ :#:        +#++:++#   +#+       +#+    +:+ :#:        +#++:++#++                                   
 +#+        +#+    +#+ +#+     +#+ +#+  +#+#+# +#+   +#+# +#+        +#+       +#+    +#+ +#+   +#+#        +#+                                    
#+#    #+# #+#    #+# #+#     #+# #+#   #+#+# #+#    #+# #+#        #+#       #+#    #+# #+#    #+# #+#    #+#                                     
########  ###    ### ###     ### ###    ####  ########  ########## ########## ########   ########   ########   "-ForegroundColor Blue


Write-Header "=================================================================================================="

Write-Accent " [VERSION 2.3 - LATEST FEATURES & DEBUG MENU]"
Write-Highlight "  * MO2 Profile Parsing    : Direct parsing for Mod Organizer 2 profile configurations."
Write-Highlight "  * Deep Conflict Analysis : Asset scanning logic to spot overlapping mods and file conflicts."
Write-Highlight "  * Patch Pinning          : Dedicated handling to lock StarUI mods and patches in position."
Write-Highlight "  * LOOT Integration       : Optional LOOT integration for automated load order sorting."
Write-Highlight "  * JSON Rule Overrides    : Custom JSON overrides to adjust sorting logic without editing main script."
Write-Highlight "  * Automated Logging      : Game-specific log folders and database tracking."
Write-Highlight "  * Safety Dry-Run Mode    : Simulation mode to test load order changes safely before writing. This is so I can build trust with the modders in different communities. I want you to know this code doesn't harm you! I'm just here to help! Now you can see every step that I perform to know if I'm okay to run!"
Write-Highlight "  * DEBUG Manager          : Integrated crash management featuring custom splash screen & log viewer."
Write-Host ""

Write-Accent " [VERSION 2.1 - STARUI & FREE LANES PATCH INTELLIGENCE]"
Write-Highlight "  * Automatic StarUI Detection      : Checks mod list for StarUI Inventory and verifies menu components."
Write-Highlight "  * Smart Free Lanes Reordering     : Shifts Free Lanes patch directly below base StarUI for .swf overrides."
Write-Highlight "  * Targeted Conflict Exclusions    : Custom-tags expected StarUI .swf overrides to prevent false error flags."
Write-Highlight "  * PowerShell List Stability Fix   : Upgraded data structures (System.Collections.Generic.List[PSCustomObject])."
Write-Host ""

Write-Accent " [VERSION 2.0 - CORE ENGINE UPDATES]"
Write-Highlight "  * Instant AppData Profile Resolver: Targets standard MO2 AppData/LocalAppData paths with manual fallback."
Write-Highlight "  * Local Database Caching          : Initializes mod_database.db to cache mod categories for offline use."
Write-Highlight "  * Deep Analysis & Conflict Checker: Scans loose files across enabled mods to output conflict reports."
Write-Highlight "  * Live Mod Counter & Progress Bar : Displays dynamic Write-Progress bar and real-time scanning counter."
Write-Highlight "  * SFSE & Framework Verification   : Ensures sfse_loader.exe placement and scans for core frameworks."
Write-Muted  "--------------------------------------------------------------------------------------------------"
Write-Host ""

# --- Critical System Notice ---
Write-Header "=================================================================================================="
Write-Header "                        IMPORTANT OPERATIONAL NOTICE                                              "
Write-Header "=================================================================================================="
Write-Warning " [!] STRONGLY RECOMMENDED: Keep Mod Organizer 2 CLOSED while running this tool."
Write-Highlight "     1. Direct File Access : Works on plugins.txt, loadorder.txt, and modlist.txt on disk."
Write-Highlight "     2. Prevents Overwrites: MO2 holds load orders in memory and overwrites external disk edits on exit."
Write-Highlight "     3. UI Synchronization : MO2 does not refresh interface elements in real time when files change."
Write-Muted  "--------------------------------------------------------------------------------------------------"
Write-Host ""

# --- Workflow Guidance ---
Write-Header "=================================================================================================="
Write-Header "                        BEST PRACTICE WORKFLOW                                                    "
Write-Header "=================================================================================================="
Write-Accent " Step 1: Close Mod Organizer 2 completely."
Write-Accent " Step 2: Run your .bat launcher script and let the sorting engine complete its process."
Write-Accent " Step 3: Reopen Mod Organizer 2 to review your newly categorized load order setup."
Write-Muted  "--------------------------------------------------------------------------------------------------"
Write-Host ""

# --- Program Features Matrix ---
Write-Header "=================================================================================================="
Write-Header "                        KEY PROGRAM FEATURES MATRIX                                              "
Write-Header "=================================================================================================="
Write-Host ("{0,-35} | {1,-60}" -f "FEATURE", "FUNCTION") -ForegroundColor DarkYellow
Write-Muted "------------------------------------+-------------------------------------------------------------"
Write-Host ("{0,-35} | {1,-60}" -f "Instant AppData Profile Finder", "Checks %APPDATA% & %LOCALAPPDATA% paths instantly.")
Write-Host ("{0,-35} | {1,-60}" -f "Live Mod Counter & Tracker", "Displays real-time terminal progress bar as mods scan.")
Write-Host ("{0,-35} | {1,-60}" -f "Local Database Caching", "Stores Nexus category data into local mod_database.db file.")
Write-Host ("{0,-35} | {1,-60}" -f "SFSE Validator", "Verifies sfse_loader.exe location in main game root directory.")
Write-Host ("{0,-35} | {1,-60}" -f "Deep Analysis & Conflict Checker", "Scans loose files to detect data overlaps & overwrite conflicts.")
Write-Host ("{0,-35} | {1,-60}" -f "Categorized Sorting Engine", "Sorts ESM/ESP/ESL files into clean logical structure.")
Write-Host ("{0,-35} | {1,-60}" -f "Dual-File MO2 Sync", "Updates plugins.txt, loadorder.txt, and modlist.txt in sync.")
Write-Muted  "--------------------------------------------------------------------------------------------------"
Write-Host ""

Write-Accent "Press any key to close dashboard..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")