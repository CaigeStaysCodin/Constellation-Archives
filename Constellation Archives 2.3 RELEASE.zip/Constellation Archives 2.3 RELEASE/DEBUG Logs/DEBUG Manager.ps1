﻿# Determine relative pathing inside DEBUG Logs folder
$LogFolder = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($LogFolder)) { $LogFolder = $PWD.Path }

# Switch to Full Screen upon opening
$Wshell = New-Object -ComObject WScript.Shell
$Wshell.SendKeys("{F11}")

$UhOhPath = Join-Path -Path $LogFolder -ChildPath "UhOh.ps1"
$LogPath  = Join-Path -Path $LogFolder -ChildPath "sorter_execution.log"

do {
    Clear-Host
    Write-Host @"
========================================================================================================================================
 _ .-') _     ('-. .-. .-')                                  _   .-')      ('-.         .-') _    ('-.                   ('-.  _  .-')   
( (  OO) )  _(  OO)\  ( OO )                                ( '.( OO )_   ( OO ).-.    ( OO ) )  ( OO ).-.             _(  OO)( \( -O )  
 \     .'_ (,------.;-----.\  ,--. ,--.     ,----.           ,--.   ,--.) / . --. /,--./ ,--,'   / . --. /  ,----.    (,------.,------.  
 ,`'--..._) |  .---'| .-.  |  |  | |  |    '  .-./-')        |   `.'   |  | \-.  \ |   \ |  |\   | \-.  \  '  .-./-')  |  .---'|   /`. ' 
 |  |  \  ' |  |    | '-' /_) |  | | .-')  |  |_( O- )       |         |.-'-'  |  ||    \|  | ).-'-'  |  | |  |_( O- ) |  |    |  /  | | 
 |  |   ' |(|  '--. | .-. `.  |  |_|( OO ) |  | .--, \       |  |'.'|  | \| |_.'  ||  .     |/  \| |_.'  | |  | .--, \(|  '--. |  |_.' | 
 |  |   / : |  .--' | |  \  | |  | | `-' /(|  | '. (_/       |  |   |  |  |  .-.  ||  |\    |    |  .-.  |(|  | '. (_/ |  .--' |  .  '.' 
 |  '--'  / |  `---.| '--'  /('  '-'(_.-'  |  '--'  |        |  |   |  |  |  | |  ||  | \   |    |  | |  | |  '--'  |  |  `---.|  |\  \  
 `-------'  `------'`------'   `-----'      `------'         `--'   `--'  `--' `--'`--'  `--'    `--' `--'  `------'   `------'`--' '--' 
=========================================================================================================================================
"@ -ForegroundColor Blue
 
    Write-Host @"
==================================================================
 __ _     _____ __       _ ______ _        _  _  __   ___\ / __ __
/  / \|\|(_  | |_ |  |  |_| |  | / \|\|   |_||_)/  |_| |  V |_ (_ 
\__\_/| |__) | |__|__|__| | | _|_\_/| |   | || \\__| |_|_   |____)
==================================================================
"@ -ForegroundColor Green

    Write-Host "  [1] Show Crash Splash Screen" -ForegroundColor Green
    Write-Host "  [2] View Crash Log Files" -ForegroundColor Yellow
    Write-Host "  [3] Coming Soon" -ForegroundColor DarkGray
    Write-Host "  [4] Exit" -ForegroundColor Red
    Write-Host ""

    $selection = Read-Host "Please select an option (1-4)"

    switch ($selection) {
        "1" {
            if (Test-Path $UhOhPath) {
                Start-Process powershell.exe -ArgumentList "-File `"$UhOhPath`""
            } else {
                Write-Host "`n[!] UhOh.ps1 was not found in $LogFolder" -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
        "2" {
            Clear-Host

            Write-Host "
__  ___ __ _  _  __   _____   _____ ____  _ _____ _  __  __  _   _   __   __   ___ ___  __  __  ___ ___  
| _\| __|  \ || |/ _] | __\ \_/ / __/ _/ || |_   _| |/__\|  \| | | | /__\ / _] | _ \ __|/  \| _\| __| _ \ 
| v | _|| -< \/ | [/\ | _| > , <| _| \_| \/ | | | | | \/ | | ' | | || \/ | [/\ | v / _|| /\ | v | _|| v / 
|__/|___|__/\__/ \__/ |___/_/ \_\___\__/\__/  |_| |_|\__/|_|\__| |___\__/ \__/ |_|_\___|_||_|__/|___|_|_\ " -ForegroundColor Blue
            Write-Host "===================================================================================================" -ForegroundColor Cyan
            Write-Host ""

            if ((Test-Path $LogPath) -and ((Get-Item $LogPath).Length -gt 0)) {
                Get-Content -Path $LogPath | Out-Host
            } else {
                Write-Host "NONE TO SHOW" -ForegroundColor Red
            }

            Write-Host ""
            Write-Host "===================================================================================================" -ForegroundColor Cyan
            Read-Host "Press Enter to return to the Main Menu..."
        }
        "3" {
            Write-Host "`n[!] Option 3 is coming soon!" -ForegroundColor Yellow
            Start-Sleep -Seconds 2
        }
        "4" {
            Write-Host "`nExiting DEBUG Manager..." -ForegroundColor Gray
            Start-Sleep -Seconds 1
            exit
        }
        default {
            Write-Host "`n[!] Invalid selection. Please choose options 1, 2, or 4." -ForegroundColor Red
            Start-Sleep -Seconds 1
        }
    }
} while ($selection -ne "4")
