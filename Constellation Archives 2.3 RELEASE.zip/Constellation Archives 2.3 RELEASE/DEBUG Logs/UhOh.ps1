﻿# Get folder path
$LogFolder = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($LogFolder)) { $LogFolder = $PWD.Path }

# Switch to Full Screen
$Wshell = New-Object -ComObject WScript.Shell
$Wshell.SendKeys("{F11}")

Clear-Host

Write-Host @"
   __  ____       ____  __    __
  / / / / /_     / __ \/ /_  / /
 / / / / __ \   / / / / __ \/ / 
/ /_/ / / / /  / /_/ / / / /_/  
\____/_/ /_/   \____/_/ /_(_)   
                                
"@ -ForegroundColor Red

Write-Host @"
    ____               _           __       ______                 __       ____      __  _                ___              __    _                
   / __ \_________    (_)__  _____/ /__    / ____/___  ____  _____/ /____  / / /___ _/ /_(_)___  ____     /   |  __________/ /_  (_)   _____  _____
  / /_/ / ___/ __ \  / / _ \/ ___/ __(_)  / /   / __ \/ __ \/ ___/ __/ _ \/ / / __ `/ __/ / __ \/ __ \   / /| | / ___/ ___/ __ \/ / | / / _ \/ ___/
 / ____/ /  / /_/ / / /  __/ /__/ /__    / /___/ /_/ / / / (__  ) /_/  __/ / / /_/ / /_/ / /_/ / / / /  / ___ |/ /  / /__/ / / / /| |/ /  __(__  ) 
/_/   /_/   \____/_/ /\___/\___/\__(_)   \____/\____/_/ /_/____/\__/\___/_/_/\__,_/\__/_/\____/_/ /_/  /_/  |_/_/   \___/_/ /_/_/ |___/\___/____/  
                /___/                                                                                                                               
"@ -ForegroundColor Blue

Write-Host @"
________/\\\\\\\\\____________________________________________/\\\________________________________/\\\______/\\\____        
 _____/\\\////////____________________________________________\/\\\_______________________________\/\\\____/\\\\\\\__       
  ___/\\\/_____________________________________________________\/\\\_______________________________\/\\\___/\\\\\\\\\_      
   __/\\\______________/\\/\\\\\\\___/\\\\\\\\\_____/\\\\\\\\\\_\/\\\_____________/\\\\\\\\_________\/\\\__\//\\\\\\\__     
    _\/\\\_____________\/\\\/////\\\_\////////\\\___\/\\\//////__\/\\\\\\\\\\____/\\\/////\\\___/\\\\\\\\\___\//\\\\\___    
     _\//\\\____________\/\\\___\///____/\\\\\\\\\\__\/\\\\\\\\\\_\/\\\/////\\\__/\\\\\\\\\\\___/\\\////\\\____\//\\\____   
      __\///\\\__________\/\\\__________/\\\/////\\\__\////////\\\_\/\\\___\/\\\_\//\\///////___\/\\\__\/\\\_____\///_____  
       ____\////\\\\\\\\\_\/\\\_________\//\\\\\\\\/\\__/\\\\\\\\\\_\/\\\___\/\\\__\//\\\\\\\\\\_\//\\\\\\\/\\_____/\\\____ 
        _______\/////////__\///___________\////////\//__\//////////__\///____\///____\//////////___\///////\//_____\///_____    
"@ -ForegroundColor Red

Write-Host "===================================================================================================" -ForegroundColor Red
Write-Host "                       CRASH DETECTED! SOMETHING WENT WRONG, PLEASE REPORT IT                             " -ForegroundColor Yellow
Write-Host "===================================================================================================" -ForegroundColor Red
Write-Host ""
Write-Host "  The sorter encountered an unexpected error and had to shut down." -ForegroundColor White
Write-Host ""
Write-Host "  [+] DEBUG LOG LOCATION:" -ForegroundColor Cyan
Write-Host "      $LogFolder" -ForegroundColor Green
Write-Host ""
Write-Host "  [+] WHAT TO DO WITH YOUR LOGS:" -ForegroundColor Cyan
Write-Host "      1. Open the 'DEBUG Logs' folder at the path above." -ForegroundColor White
Write-Host "      2. Find 'sorter_execution.log'." -ForegroundColor White
Write-Host "      3. Copy its contents or attach the log file when asking for help / reporting on Nexus Mods or !" -ForegroundColor White
Write-Host ""
Write-Host "===================================================================================================" -ForegroundColor Red
Write-Host ""
Read-Host "Press Enter to close the crash splash screen..."
exit
