param (
    [string]$WorkingDir = $PSScriptRoot,
    [string]$ApiKey     = "" # Optional: Enter Nexus Mods API Key
)

# Fallback if PSScriptRoot is blank when launched externally
if ([string]::IsNullOrWhiteSpace($WorkingDir)) {
    $WorkingDir = $PWD.Path
}

# ----------------------------------------------------
# Log Generation Setup (DEBUG Logs Folder & Handlers)
# ----------------------------------------------------
$DebugLogsDir = Join-Path -Path $WorkingDir -ChildPath "DEBUG Logs"
if (-not (Test-Path $DebugLogsDir)) {
    New-Item -ItemType Directory -Path $DebugLogsDir -Force | Out-Null
}

$ExecutionLog       = Join-Path -Path $DebugLogsDir -ChildPath "sorter_execution.log"
$UhOhScript         = Join-Path -Path $DebugLogsDir -ChildPath "UhOh.ps1"
$DebugManagerScript = Join-Path -Path $DebugLogsDir -ChildPath "DEBUG Manager.ps1"

"=== Sorter Execution Started: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ===" | Out-File -FilePath $ExecutionLog -Encoding utf8

# Auto-generate or update UhOh.ps1 template
$uhohContent = @'
# Get folder path
$LogFolder = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($LogFolder)) { $LogFolder = $PWD.Path }

# Switch to Full Screen
$Wshell = New-Object -ComObject WScript.Shell
$Wshell.SendKeys("{F11}")

Clear-Host

Write-Host @"
   __  ____       ____  __    __
  / / / / /_     / __ \/ /_  / /
 / / / / __ \   / / / / __ \/ / 
/ /_/ / / / /  / /_/ / / / /_/  
\____/_/ /_/   \____/_/ /_(_)   
                                
"@ -ForegroundColor Red

Write-Host @"
    ____               _           __       ______                 __       ____      __  _                ___              __    _                
   / __ \_________    (_)__  _____/ /__    / ____/___  ____  _____/ /____  / / /___ _/ /_(_)___  ____     /   |  __________/ /_  (_)   _____  _____
  / /_/ / ___/ __ \  / / _ \/ ___/ __(_)  / /   / __ \/ __ \/ ___/ __/ _ \/ / / __ `/ __/ / __ \/ __ \   / /| | / ___/ ___/ __ \/ / | / / _ \/ ___/
 / ____/ /  / /_/ / / /  __/ /__/ /__    / /___/ /_/ / / / (__  ) /_/  __/ / / /_/ / /_/ / /_/ / / / /  / ___ |/ /  / /__/ / / / /| |/ /  __(__  ) 
/_/   /_/   \____/_/ /\___/\___/\__(_)   \____/\____/_/ /_/____/\__/\___/_/_/\__,_/\__/_/\____/_/ /_/  /_/  |_/_/   \___/_/ /_/_/ |___/\___/____/  
                /___/                                                                                                                               
"@ -ForegroundColor Blue

Write-Host @"
________/\\\\\\\\\____________________________________________/\\\________________________________/\\\______/\\\____        
 _____/\\\////////____________________________________________\/\\\_______________________________\/\\\____/\\\\\\\__       
  ___/\\\/_____________________________________________________\/\\\_______________________________\/\\\___/\\\\\\\\\_      
   __/\\\______________/\\/\\\\\\\___/\\\\\\\\\_____/\\\\\\\\\\_\/\\\_____________/\\\\\\\\_________\/\\\__\//\\\\\\\__     
    _\/\\\_____________\/\\\/////\\\_\////////\\\___\/\\\//////__\/\\\\\\\\\\____/\\\/////\\\___/\\\\\\\\\___\//\\\\\___    
     _\//\\\____________\/\\\___\///____/\\\\\\\\\\__\/\\\\\\\\\\_\/\\\/////\\\__/\\\\\\\\\\\___/\\\////\\\____\//\\\____   
      __\///\\\__________\/\\\__________/\\\/////\\\__\////////\\\_\/\\\___\/\\\_\//\\///////___\/\\\__\/\\\_____\///_____  
       ____\////\\\\\\\\\_\/\\\_________\//\\\\\\\\/\\__/\\\\\\\\\\_\/\\\___\/\\\__\//\\\\\\\\\\_\//\\\\\\\/\\_____/\\\____ 
        _______\/////////__\///___________\////////\//__\//////////__\///____\///____\//////////___\///////\//_____\///_____    
"@ -ForegroundColor Red

Write-Host "===================================================================================================" -ForegroundColor Red
Write-Host "                       CRASH DETECTED! SOMETHING WENT WRONG, PLEASE REPORT IT                             " -ForegroundColor Yellow
Write-Host "===================================================================================================" -ForegroundColor Red
Write-Host ""
Write-Host "  The sorter encountered an unexpected error and had to shut down." -ForegroundColor White
Write-Host ""
Write-Host "  [+] DEBUG LOG LOCATION:" -ForegroundColor Cyan
Write-Host "      $LogFolder" -ForegroundColor Green
Write-Host ""
Write-Host "  [+] WHAT TO DO WITH YOUR LOGS:" -ForegroundColor Cyan
Write-Host "      1. Open the 'DEBUG Logs' folder at the path above." -ForegroundColor White
Write-Host "      2. Find 'sorter_execution.log'." -ForegroundColor White
Write-Host "      3. Copy its contents or attach the log file when asking for help / reporting on Nexus Mods or !" -ForegroundColor White
Write-Host ""
Write-Host "===================================================================================================" -ForegroundColor Red
Write-Host ""
Read-Host "Press Enter to close the crash splash screen..."
exit
'@
$uhohContent | Out-File -FilePath $UhOhScript -Encoding utf8

# Auto-generate or update DEBUG Manager.ps1 template
$debugManagerContent = @'
# Determine relative pathing inside DEBUG Logs folder
$LogFolder = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($LogFolder)) { $LogFolder = $PWD.Path }

# Switch to Full Screen upon opening
$Wshell = New-Object -ComObject WScript.Shell
$Wshell.SendKeys("{F11}")

$UhOhPath = Join-Path -Path $LogFolder -ChildPath "UhOh.ps1"
$LogPath  = Join-Path -Path $LogFolder -ChildPath "sorter_execution.log"

do {
    Clear-Host
    Write-Host @"
========================================================================================================================================
 _ .-') _     ('-. .-. .-')                                  _   .-')      ('-.         .-') _    ('-.                   ('-.  _  .-')   
( (  OO) )  _(  OO)\  ( OO )                                ( '.( OO )_   ( OO ).-.    ( OO ) )  ( OO ).-.             _(  OO)( \( -O )  
 \     .'_ (,------.;-----.\  ,--. ,--.     ,----.           ,--.   ,--.) / . --. /,--./ ,--,'   / . --. /  ,----.    (,------.,------.  
 ,`'--..._) |  .---'| .-.  |  |  | |  |    '  .-./-')        |   `.'   |  | \-.  \ |   \ |  |\   | \-.  \  '  .-./-')  |  .---'|   /`. ' 
 |  |  \  ' |  |    | '-' /_) |  | | .-')  |  |_( O- )       |         |.-'-'  |  ||    \|  | ).-'-'  |  | |  |_( O- ) |  |    |  /  | | 
 |  |   ' |(|  '--. | .-. `.  |  |_|( OO ) |  | .--, \       |  |'.'|  | \| |_.'  ||  .     |/  \| |_.'  | |  | .--, \(|  '--. |  |_.' | 
 |  |   / : |  .--' | |  \  | |  | | `-' /(|  | '. (_/       |  |   |  |  |  .-.  ||  |\    |    |  .-.  |(|  | '. (_/ |  .--' |  .  '.' 
 |  '--'  / |  `---.| '--'  /('  '-'(_.-'  |  '--'  |        |  |   |  |  |  | |  ||  | \   |    |  | |  | |  '--'  |  |  `---.|  |\  \  
 `-------'  `------'`------'   `-----'      `------'         `--'   `--'  `--' `--'`--'  `--'    `--' `--'  `------'   `------'`--' '--' 
=========================================================================================================================================
"@ -ForegroundColor Blue
 
    Write-Host @"
==================================================================
 __ _     _____ __       _ ______ _        _  _  __   ___\ / __ __
/  / \|\|(_  | |_ |  |  |_| |  | / \|\|   |_||_)/  |_| |  V |_ (_ 
\__\_/| |__) | |__|__|__| | | _|_\_/| |   | || \\__| |_|_   |____)
==================================================================
"@ -ForegroundColor Green

    Write-Host "  [1] Show Crash Splash Screen" -ForegroundColor Green
    Write-Host "  [2] View Crash Log Files" -ForegroundColor Yellow
    Write-Host "  [3] Coming Soon" -ForegroundColor DarkGray
    Write-Host "  [4] Exit" -ForegroundColor Red
    Write-Host ""

    $selection = Read-Host "Please select an option (1-4)"

    switch ($selection) {
        "1" {
            if (Test-Path $UhOhPath) {
                Start-Process powershell.exe -ArgumentList "-File `"$UhOhPath`""
            } else {
                Write-Host "`n[!] UhOh.ps1 was not found in $LogFolder" -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
        "2" {
            Clear-Host

            Write-Host "
__  ___ __ _  _  __   _____   _____ ____  _ _____ _  __  __  _   _   __   __   ___ ___  __  __  ___ ___  
| _\| __|  \ || |/ _] | __\ \_/ / __/ _/ || |_   _| |/__\|  \| | | | /__\ / _] | _ \ __|/  \| _\| __| _ \ 
| v | _|| -< \/ | [/\ | _| > , <| _| \_| \/ | | | | | \/ | | ' | | || \/ | [/\ | v / _|| /\ | v | _|| v / 
|__/|___|__/\__/ \__/ |___/_/ \_\___\__/\__/  |_| |_|\__/|_|\__| |___\__/ \__/ |_|_\___|_||_|__/|___|_|_\ " -ForegroundColor Blue
            Write-Host "===================================================================================================" -ForegroundColor Cyan
            Write-Host ""

            if ((Test-Path $LogPath) -and ((Get-Item $LogPath).Length -gt 0)) {
                Get-Content -Path $LogPath | Out-Host
            } else {
                Write-Host "NONE TO SHOW" -ForegroundColor Red
            }

            Write-Host ""
            Write-Host "===================================================================================================" -ForegroundColor Cyan
            Read-Host "Press Enter to return to the Main Menu..."
        }
        "3" {
            Write-Host "`n[!] Option 3 is coming soon!" -ForegroundColor Yellow
            Start-Sleep -Seconds 2
        }
        "4" {
            Write-Host "`nExiting DEBUG Manager..." -ForegroundColor Gray
            Start-Sleep -Seconds 1
            exit
        }
        default {
            Write-Host "`n[!] Invalid selection. Please choose options 1, 2, or 4." -ForegroundColor Red
            Start-Sleep -Seconds 1
        }
    }
} while ($selection -ne "4")
'@
$debugManagerContent | Out-File -FilePath $DebugManagerScript -Encoding utf8

function Log-Msg {
    param(
        [string]$Message,
        [string]$Level = "INFO",
        [ConsoleColor]$ForegroundColor = [ConsoleColor]::White,
        [switch]$NoConsole
    )
    $timeStamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "[$timeStamp] [$Level] $Message" | Out-File -FilePath $ExecutionLog -Append -Encoding utf8
    if (-not $NoConsole) {
        Write-Host $Message -ForegroundColor $ForegroundColor
    }
}

# Wrap execution in Global Try/Catch
try {
    # 1. Automatically switch to Full Screen mode
    $Wshell = New-Object -ComObject WScript.Shell
    $Wshell.SendKeys("{F11}")

    Clear-Host

    Write-Host "_________                         __         .__  .__          __  .__                   _____                .__    .__                     
\_   ___ \  ____   ____   _______/  |_  ____ |  | |  | _____ _/  |_|__| ____   ____     /  _  \_______   ____ |  |__ |__|__  __ ____   ______
/    \  \/ /  _ \ /    \ /  ___/\   __\/ __ \|  | |  | \__  \\   __\  |/  _ \ /    \   /  /_\  \_  __ \_/ ___\|  |  \|  \  \/ // __ \ /  ___/
\     \___(  <_> )   |  \\___ \  |  | \  ___/|  |_|  |__/ __ \|  | |  (  <_> )   |  \ /    |    \  | \/\  \___|   Y  \  |\   /\  ___/ \___ \ 
 \______  /\____/|___|  /____  > |__|  \___  >____/____(____  /__| |__|\____/|___|  / \____|__  /__|    \___  >___|  /__| |_/  \___  >____  >
        \/            \/     \/            \/               \/                    \/          \/            \/     \/              \/     \/ " -ForegroundColor Blue

    Write-Host "    _       _           ___          _             ___              _        
   /_\ _  _| |_ ___ ___/ __| ___ _ _| |_ ___ _ _  / __| ___ _ ___ _(_)__ ___ 
  / _ \ || |  _/ _ \___\__ \/ _ \ '_|  _/ -_) '_| \__ \/ -_) '_\ V / / _/ -_)
 /_/ \_\_,_|\__\___/   |___/\___/_|  \__\___|_|   |___/\___|_|  \_/|_\__\___|
                                                                             " -ForegroundColor Green

    Write-Host @"
===================================================
  Starfield MO2 Mod Auto Sorter, Conflict Checker & Sorter
===================================================

 _____________________
< Don't forget Roach Race CDPR! (Just a nod to my fav game!!) >
 ---------------------
        \   ^__^
         \  (oo)\_______
            (__)\       )\/\
                ||----w |
                ||     ||
"@ -ForegroundColor DarkGreen

    Log-Msg -Message "Remember, logs won't show up in the Constellation Archives folder unless you back out, then go back in" -Level "INFO" -ForegroundColor Red

    # ----------------------------------------------------
    # Custom JSON Override Rules Loader
    # ----------------------------------------------------
    $JsonRulesFile = Join-Path -Path $WorkingDir -ChildPath "custom_rules.json"
    $CustomRules = $null

    if (-not (Test-Path $JsonRulesFile)) {
        $defaultJson = @{
            ForceCategory = @{
                "ExamplePlugin.esm" = "User Interface"
            }
            PriorityPlugins = @(
                "StarfieldCommunityPatch.esm"
            )
        }
        $defaultJson | ConvertTo-Json -Depth 3 | Out-File -FilePath $JsonRulesFile -Encoding utf8
        Log-Msg -Message "Generated default custom_rules.json template." -Level "INFO" -NoConsole
    }

    if (Test-Path $JsonRulesFile) {
        try {
            $CustomRules = Get-Content -Path $JsonRulesFile -Raw | ConvertFrom-Json
            Log-Msg -Message "Loaded custom JSON overrides from custom_rules.json." -Level "INFO" -NoConsole
        } catch {
            Log-Msg -Message "Warning: Failed to parse custom_rules.json file." -Level "WARN" -NoConsole
        }
    }

    # ----------------------------------------------------
    # Custom Fancy Loading Bar Function (Blue Accent)
    # ----------------------------------------------------
    function Show-FancyProgress {
        param(
            [int]$Current,
            [int]$Total,
            [string]$Activity = "Processing"
        )
        if ($Total -le 0) { return }
        $percent = [math]::Min(100, [math]::Max(0, [math]::Round(($Current / $Total) * 100)))
        $barWidth = 30
        $completedWidth = [math]::Round(($percent / 100) * $barWidth)
        $remainingWidth = $barWidth - $completedWidth

        $barFill = "[" + ("#" * $completedWidth) + ("-" * $remainingWidth) + "]"
        
        Write-Host -NoNewline "`r  $Activity $barFill $percent% ($Current/$Total)   " -ForegroundColor Blue
    }

    # ----------------------------------------------------
    # Local Database Setup (.db file handling)
    # ----------------------------------------------------
    $DbFilePath = Join-Path -Path $WorkingDir -ChildPath "mod_database.db"

    function Initialize-LocalDatabase {
        param ([string]$Path)
        if (-not (Test-Path $Path)) {
            "ModID,Category" | Out-File -FilePath $Path -Encoding utf8
        }
    }

    function Get-CachedCategory {
        param ([int]$ModId, [string]$Path)
        if (-not (Test-Path $Path) -or $ModId -le 0) { return $null }
        $lines = Get-Content -Path $Path
        foreach ($line in $lines) {
            $parts = $line.Split(",")
            if ($parts.Count -ge 2 -and $parts[0].Trim() -eq $ModId.ToString()) {
                return $parts[1].Trim()
            }
        }
        return $null
    }

    function Set-CachedCategory {
        param ([int]$ModId, [string]$Category, [string]$Path)
        if ($ModId -le 0 -or [string]::IsNullOrWhiteSpace($Category)) { return }
        if (Test-Path $Path) {
            $existing = Get-CachedCategory -ModId $ModId -Path $Path
            if (-not $existing) {
                "$ModId,$Category" | Out-File -FilePath $Path -Append -Encoding utf8
            }
        }
    }

    Initialize-LocalDatabase -Path $DbFilePath

    function Get-NexusModInfo {
        param ([int]$ModId, [string]$Key)
        if ([string]::IsNullOrEmpty($Key) -or $ModId -le 0) { return $null }
        $headers = @{ "apikey" = $Key; "accept" = "application/json" }
        try {
            return Invoke-RestMethod -Uri "https://api.nexusmods.com/v1/games/starfield/mods/$ModId.json" -Headers $headers -Method Get
        } catch {
            return $null
        }
    }

    # ----------------------------------------------------
    # 0. Initial Setup & Feature Options
    # ----------------------------------------------------
    
    # [1] Soft Launch / Dry Run Mode Prompt (Placed First)
    Write-Host "`n# ----------------------------------------------------" -ForegroundColor DarkGreen
    Write-Host "# Soft Launch / Dry Run Mode" -ForegroundColor Blue
    Write-Host "# ----------------------------------------------------" -ForegroundColor DarkGreen

    Log-Msg -Message "Would you like to run in Soft Launch / Preview Mode? (Calculates preview without altering MO2 profile files)" -Level "INFO" -ForegroundColor Yellow
    Write-Host "[1] Soft Launch (Preview / Dry Run mode)" -ForegroundColor Green
    Write-Host "[2] Full Launch (Apply changes directly to MO2)" -ForegroundColor Red

    $softChoice = Read-Host "`nChoice (1 or 2)"

    if ($softChoice -eq "1") {
        $IsSoftLaunch = $true
        Log-Msg -Message "  [!] SOFT LAUNCH ACTIVE: Results will be logged to text files for preview only." -Level "WARN" -ForegroundColor Yellow
    } else {
        $IsSoftLaunch = $false
        Log-Msg -Message "  [+] FULL LAUNCH ACTIVE: Changes will be written directly to MO2 profile." -Level "INFO" -ForegroundColor Green
    }

    # [2] Deep Analysis Sorting Prompt
    Write-Host "`n# ----------------------------------------------------" -ForegroundColor DarkGreen
    Write-Host "# Feature Prompt: Extended Sorting Logic" -ForegroundColor Blue
    Write-Host "# ----------------------------------------------------" -ForegroundColor DarkGreen

    Log-Msg -Message "Would you like to run Deep Analysis sorting (checks categories, dependencies, and file conflicts)?" -Level "INFO" -ForegroundColor Yellow
    Write-Host "[1] Um..DUH!!" -ForegroundColor Green
    Write-Host "[2] I'd rather not, just use standard method" -ForegroundColor Red

    $sortingChoice = Read-Host "`nChoice (1 or 2)"

    if ($sortingChoice -eq "1" -or $sortingChoice -match "DUH") {
        Log-Msg -Message "`n[+] Engaging Deep Analysis & Smart Category Sorting..." -Level "INFO" -ForegroundColor Green
        $EnableDeepAnalysis = $true

        if ([string]::IsNullOrWhiteSpace($ApiKey)) {
            Log-Msg -Message "`nTo query Nexus Mods for deep category info and requirements:" -Level "INFO" -ForegroundColor Cyan
            $userApiKey = Read-Host "Please paste your PERSONAL Nexus Mods API Key (or press Enter to skip API checks)"

            if (-not [string]::IsNullOrWhiteSpace($userApiKey)) {
                $ApiKey = $userApiKey.Trim()
                Log-Msg -Message "  [OK] Nexus API Key saved for this session." -Level "INFO" -ForegroundColor Green
            } else {
                Log-Msg -Message "  [!] No key provided. Checking local .db cache & file heuristics." -Level "WARN" -ForegroundColor Red
            }
        }
    } else {
        Log-Msg -Message "`n[-] Bypassing extended checks. Running standard sorting method..." -Level "INFO" -ForegroundColor Gray
        $EnableDeepAnalysis = $false
    }

    # [3] LOOT Engine Prompt
    Write-Host "`n# ----------------------------------------------------" -ForegroundColor DarkGreen
    Write-Host "# Optional LOOT Engine Integration" -ForegroundColor Blue
    Write-Host "# ----------------------------------------------------" -ForegroundColor DarkGreen

    Log-Msg -Message "Would you like to run LOOT (Load Order Optimisation Tool) CLI integration?" -Level "INFO" -ForegroundColor Yellow
    Write-Host "[1] Yes, attempt LOOT automated sorting" -ForegroundColor Green
    Write-Host "[2] No, stick with built-in categorized sorting" -ForegroundColor Red

    $lootChoice = Read-Host "`nChoice (1 or 2)"

    if ($lootChoice -eq "1") {
        $EnableLOOT = $true
        Log-Msg -Message "  [+] LOOT Integration Enabled." -Level "INFO" -ForegroundColor Green
    } else {
        $EnableLOOT = $false
        Log-Msg -Message "  [-] LOOT Integration Disabled. Using standard internal sorting logic." -Level "INFO" -ForegroundColor Gray
    }

    # ----------------------------------------------------
    # Initialization & Working Directory Setup
    # ----------------------------------------------------
    $InstalledModsLog   = Join-Path -Path $WorkingDir -ChildPath "installed mods list.txt"
    $LooseFilesLog      = Join-Path -Path $WorkingDir -ChildPath "loose files mods sorted.txt"
    $LoadOrderBeforeLog = Join-Path -Path $WorkingDir -ChildPath "load order before.txt"
    $LoadOrderAfterLog  = Join-Path -Path $WorkingDir -ChildPath "load order after.txt"
    $ConflictReportLog  = Join-Path -Path $WorkingDir -ChildPath "conflict analysis report.txt"

    Log-Msg -Message "`n[1/8] Instantly locating MO2 AppData profiles..." -Level "INFO" -ForegroundColor Cyan

    $ProfilePath = $null
    $InstanceRoot = $null
    $ProfileBasePath = $null

    $PotentialAppDataProfiles = @(
        "$env:APPDATA\ModOrganizer\Starfield\profiles",
        "$env:LOCALAPPDATA\ModOrganizer\Starfield\profiles",
        "$env:APPDATA\ModOrganizer\Common\Starfield\profiles",
        "$env:LOCALAPPDATA\ModOrganizer\Common\Starfield\profiles"
    )

    foreach ($path in $PotentialAppDataProfiles) {
        if (Test-Path $path) {
            $ProfileBasePath = $path
            $InstanceRoot = (Get-Item (Join-Path $ProfileBasePath "..")).FullName
            Log-Msg -Message "  [OK] Found AppData instance: $InstanceRoot" -Level "INFO" -ForegroundColor Green
            break
        }
    }

    if (-not $ProfileBasePath) {
        foreach ($baseDir in @("$env:APPDATA\ModOrganizer", "$env:LOCALAPPDATA\ModOrganizer")) {
            if (Test-Path $baseDir) {
                $subFolders = Get-ChildItem -Path $baseDir -Directory -ErrorAction SilentlyContinue
                foreach ($sub in $subFolders) {
                    $checkProfilePath = Join-Path $sub.FullName "profiles"
                    if (Test-Path $checkProfilePath) {
                        $ProfileBasePath = $checkProfilePath
                        $InstanceRoot = $sub.FullName
                        Log-Msg -Message "  [OK] Located instance under: $InstanceRoot" -Level "INFO" -ForegroundColor Green
                        break
                    }
                }
            }
            if ($ProfileBasePath) { break }
        }
    }

    if ($ProfileBasePath -and (Test-Path $ProfileBasePath)) {
        $profiles = Get-ChildItem -Path $ProfileBasePath -Directory -ErrorAction SilentlyContinue
        if ($profiles) {
            $starfieldProfile = $profiles | Where-Object { $_.Name -match "Starfield|Default" } | Select-Object -First 1
            if ($starfieldProfile) {
                $ProfilePath = $starfieldProfile.FullName
            } else {
                $ProfilePath = ($profiles | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName
            }
        }
    }

    if (-not $ProfilePath -or -not (Test-Path $ProfilePath)) {
        Log-Msg -Message "Could not automatically locate your AppData MO2 Starfield profile folder instantly." -Level "WARN" -ForegroundColor Yellow
        $UserPath = Read-Host "Please paste the full path to your AppData Starfield profile folder"
        if (Test-Path $UserPath) {
            $ProfilePath = $UserPath
            $InstanceRoot = (Get-Item (Join-Path $ProfilePath "..")).FullName
        } else {
            throw "Profile Path not found by user."
        }
    }

    $ModsDir = Join-Path -Path $InstanceRoot -ChildPath "mods"
    if (-not (Test-Path $ModsDir)) {
        $ParentOfInstance = (Get-Item (Join-Path $InstanceRoot "..")).FullName
        if (Test-Path (Join-Path $ParentOfInstance "mods")) {
            $ModsDir = Join-Path $ParentOfInstance "mods"
        } else {
            $UserModsDir = Read-Host "Enter the path to your MO2 'mods' folder"
            if (Test-Path $UserModsDir) {
                $ModsDir = $UserModsDir
            }
        }
    }

    $GameDir = $null
    $PossibleGamePaths = @(
        "C:\Program Files (x86)\Steam\steamapps\common\Starfield",
        "C:\Steam\steamapps\common\Starfield",
        "D:\Steam\steamapps\common\Starfield",
        "C:\XboxGames\Starfield\Content"
    )

    foreach ($gPath in $PossibleGamePaths) {
        if (Test-Path (Join-Path $gPath "Starfield.exe")) {
            $GameDir = $gPath
            break
        }
    }

    if (-not $GameDir) {
        $UserGameDir = Read-Host "Enter your main Starfield game directory path"
        if (Test-Path $UserGameDir) {
            $GameDir = $UserGameDir
        }
    }

    Log-Msg -Message "Profile Directory: $ProfilePath" -Level "INFO" -ForegroundColor Green
    Log-Msg -Message "Mods Directory:    $ModsDir" -Level "INFO" -ForegroundColor Green
    if ($GameDir) {
        Log-Msg -Message "Game Directory:    $GameDir" -Level "INFO" -ForegroundColor Green
    } else {
        Log-Msg -Message "Game Directory:    [Not Found automatically]" -Level "WARN" -ForegroundColor Yellow
    }

    # ----------------------------------------------------
    # 1. Parse Profile status (modlist.txt)
    # ----------------------------------------------------
    $ModListFile = Join-Path -Path $ProfilePath -ChildPath "modlist.txt"
    $ModStatusMap = @{}

    if (Test-Path $ModListFile) {
        Get-Content -Path $ModListFile | ForEach-Object {
            $line = $_.Trim()
            if ($line.StartsWith("+")) {
                $ModStatusMap[$line.Substring(1)] = "ENABLED"
            } elseif ($line.StartsWith("-")) {
                $ModStatusMap[$line.Substring(1)] = "DISABLED"
            }
        }
    }

    # ----------------------------------------------------
    # 2. Categorize & Scan Mods with Live API Queue & Blue Progress Bar
    # ----------------------------------------------------
    Log-Msg -Message "[2/8] Scanning MO2 'mods' folder with live API queries..." -Level "INFO" -ForegroundColor Blue

    $InstalledModOutput = @()
    $EnabledModFolders  = @()
    $LooseFileMods      = @()
    $PluginMods         = @()
    $PluginCategoryMap  = @{} 

    $totalModsFound     = 0
    $scannedCount       = 0
    $hasStarUI          = $false
    $hasFreeLanesPatch  = $false

    if (Test-Path $ModsDir) {
        $DiskModFolders = @(Get-ChildItem -Path $ModsDir -Directory)
        $totalModsFound = $DiskModFolders.Count
        
        foreach ($folder in $DiskModFolders) {
            $scannedCount++
            $name   = $folder.Name
            
            if ($name -match "StarUI") {
                $hasStarUI = $true
                if ($name -match "Free Lanes Compatibility Patch") {
                    $hasFreeLanesPatch = $true
                }
            }

            $status = if ($ModStatusMap.ContainsKey($name)) { $ModStatusMap[$name] } else { "UNTRACKED" }
            $prefix = if ($status -eq "ENABLED") { "+" } else { "-" }

            $InstalledModOutput += "[$status] $name"
            if ($status -eq "ENABLED") {
                $EnabledModFolders += $folder.FullName
            }

            $nexusCategory = ""
            $metaFile = Join-Path -Path $folder.FullName -ChildPath "meta.ini"
            if (Test-Path $metaFile) {
                $modIdLine = Get-Content -Path $metaFile | Where-Object { $_ -like "modid=*" }
                if ($modIdLine) {
                    [int]$modId = $modIdLine.Split("=")[1].Trim()
                    if ($modId -gt 0) {
                        $nexusCategory = Get-CachedCategory -ModId $modId -Path $DbFilePath
                        
                        if ([string]::IsNullOrWhiteSpace($nexusCategory) -and $EnableDeepAnalysis -and -not [string]::IsNullOrWhiteSpace($ApiKey)) {
                            Log-Msg -Message "  [API] Querying Nexus for $name (ID: $modId)..." -Level "INFO" -ForegroundColor Cyan
                            $nexusData = Get-NexusModInfo -ModId $modId -Key $ApiKey
                            if ($nexusData -and $nexusData.category) {
                                $nexusCategory = $nexusData.category
                                Set-CachedCategory -ModId $modId -Category $nexusCategory -Path $DbFilePath
                            }
                            Start-Sleep -Milliseconds 150
                        }
                    }
                }
            }

            Show-FancyProgress -Current $scannedCount -Total $totalModsFound -Activity "Scanning Mods:"

            $pluginsInMod = Get-ChildItem -Path "$($folder.FullName)\*" -Include *.esm, *.esp, *.esl -Recurse -ErrorAction SilentlyContinue
            $hasPlugin = ($pluginsInMod.Count -gt 0)

            foreach ($plug in $pluginsInMod) {
                if ($CustomRules -and $CustomRules.ForceCategory -and $CustomRules.ForceCategory.PSObject.Properties[$plug.Name]) {
                    $PluginCategoryMap[$plug.Name] = $CustomRules.ForceCategory.PSObject.Properties[$plug.Name].Value
                } else {
                    $PluginCategoryMap[$plug.Name] = $nexusCategory
                }
            }

            $modObj = [PSCustomObject]@{
                Name          = $name
                Status        = $status
                Prefix        = $prefix
                Path          = $folder.FullName
                NexusCategory = $nexusCategory
            }

            if ($hasPlugin) {
                $PluginMods += $modObj
            } else {
                $LooseFileMods += $modObj
            }
        }
        Write-Host ""
    } else {
        Log-Msg -Message "Warning: Could not locate 'mods' directory at $ModsDir" -Level "WARN" -ForegroundColor Red
    }

    if ($hasStarUI) {
        Log-Msg -Message "  [OK] StarUI mod(s) detected." -Level "INFO" -ForegroundColor Green
        if ($hasFreeLanesPatch) {
            Log-Msg -Message "  [OK] StarUI Inventory - Free Lanes Compatibility Patch detected." -Level "INFO" -ForegroundColor Green
        } else {
            Log-Msg -Message "  [!] Warning: StarUI detected, but 'StarUI Inventory - Free Lanes Compatibility Patch' was not found!" -Level "WARN" -ForegroundColor Yellow
        }
    }

    Log-Msg -Message "  [OK] Scan complete! Found $totalModsFound total mods ($($PluginMods.Count) plugin mods, $($LooseFileMods.Count) loose file mods)." -Level "INFO" -ForegroundColor Green
    $InstalledModOutput | Out-File -FilePath $InstalledModsLog -Encoding utf8

    $SortedLooseMods = $LooseFileMods | Sort-Object Name
    $LooseFileOutput = $SortedLooseMods | ForEach-Object { "[$($_.Status)] $($_.Name)" }
    $LooseFileOutput | Out-File -FilePath $LooseFilesLog -Encoding utf8

    # ----------------------------------------------------
    # 3. Conflict Detection Engine (File Overlaps)
    # ----------------------------------------------------
    if ($EnableDeepAnalysis) {
        Log-Msg -Message "[3/8] Running Conflict Analysis across enabled mods..." -Level "INFO" -ForegroundColor Blue

        $FileMap = @{}
        $ConflictList = @()

        foreach ($modPath in $EnabledModFolders) {
            $modName = Split-Path $modPath -Leaf
            $files = Get-ChildItem -Path $modPath -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -notlike "*.meta" }

            foreach ($file in $files) {
                $relativePath = $file.FullName.Substring($modPath.Length)
                if (-not $FileMap.ContainsKey($relativePath)) {
                    $FileMap[$relativePath] = [System.Collections.Generic.List[string]]::new()
                }
                $FileMap[$relativePath].Add($modName)
            }
        }

        foreach ($entry in $FileMap.GetEnumerator()) {
            if ($entry.Value.Count -gt 1) {
                $isStarUIPatchConflict = $false
                if ($entry.Key -match "\.swf$" -and ($entry.Value -contains "StarUI Inventory") -and ($entry.Value -contains "StarUI Inventory - Free Lanes Compatibility Patch")) {
                    $isStarUIPatchConflict = $true
                }

                $conflictLine = "File: $($entry.Key)"
                if ($isStarUIPatchConflict) {
                    $conflictLine += " [EXPECTED PATCH OVERRIDE]"
                }
                $ConflictList += $conflictLine
                $ConflictList += "  Overridden by: " + ($entry.Value -join " <--- ")
            }
        }

        if ($ConflictList.Count -gt 0) {
            $ConflictList += ""
            $ConflictList += "========================================================="
            $ConflictList += "           POSSIBLE FIXES & RECOMMENDATIONS"
            $ConflictList += "========================================================="
            $ConflictList += "1. UI / SWF Menu Conflicts (StarUI & Patches):"
            $ConflictList += "   - It is NORMAL and REQUIRED for compatibility patches to override base UI."
            $ConflictList | Out-File -FilePath $ConflictReportLog -Encoding utf8
            Log-Msg -Message "  [!] Conflicts detected! Report saved to: $ConflictReportLog" -Level "WARN" -ForegroundColor Yellow
        } else {
            Log-Msg -Message "  [OK] No file overwrite conflicts found." -Level "INFO" -ForegroundColor Green
        }
    } else {
        Log-Msg -Message "[3/8] Standard Mode: Skipping File Conflict Analysis..." -Level "INFO" -ForegroundColor Gray
    }

    # ----------------------------------------------------
    # 4. Dependency & Script Extender Check
    # ----------------------------------------------------
    Log-Msg -Message "[4/8] Checking Script Extender & Core Dependencies..." -Level "INFO" -ForegroundColor Blue

    $SFSEFound = $false
    if ($GameDir -and (Test-Path (Join-Path $GameDir "sfse_loader.exe"))) {
        $SFSEFound = $true
        Log-Msg -Message "  [OK] Starfield Script Extender (sfse_loader.exe) verified in game root." -Level "INFO" -ForegroundColor Green
    } else {
        Log-Msg -Message "  [WARNING] sfse_loader.exe not detected in main game directory ($GameDir)." -Level "WARN" -ForegroundColor Red
    }

    # ----------------------------------------------------
    # 5. Update MO2 Left Panel (modlist.txt)
    # ----------------------------------------------------
    Log-Msg -Message "[5/8] Validating MO2 left panel order..." -Level "INFO" -ForegroundColor Blue

    $ExistingModListLines = if (Test-Path $ModListFile) { Get-Content -Path $ModListFile } else { @() }
    $FullModListOrder = New-Object 'System.Collections.Generic.List[PSCustomObject]'
    foreach ($line in $ExistingModListLines) {
        if ($line.Length -gt 1) {
            $FullModListOrder.Add([PSCustomObject]@{
                Name   = $line.Substring(1)
                Prefix = $line.Substring(0, 1)
                Status = if ($line.Substring(0, 1) -eq "+") { "ENABLED" } else { "DISABLED" }
            })
        }
    }

    $ExistingNames = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($item in $FullModListOrder) { [void]$ExistingNames.Add($item.Name) }

    foreach ($folder in $DiskModFolders) {
        if (-not $ExistingNames.Contains($folder.Name)) {
            $status = if ($ModStatusMap.ContainsKey($folder.Name)) { $ModStatusMap[$folder.Name] } else { "ENABLED" }
            $FullModListOrder.Add([PSCustomObject]@{
                Name   = $folder.Name
                Prefix = if ($status -eq "ENABLED") { "+" } else { "-" }
                Status = $status
            })
        }
    }

    $starUIIndex = -1
    $patchIndex = -1

    for ($i = 0; $i -lt $FullModListOrder.Count; $i++) {
        if ($FullModListOrder[$i].Name -eq "StarUI Inventory") { $starUIIndex = $i }
        elseif ($FullModListOrder[$i].Name -eq "StarUI Inventory - Free Lanes Compatibility Patch") { $patchIndex = $i }
    }

    if ($starUIIndex -ge 0 -and $patchIndex -ge 0 -and $patchIndex -lt $starUIIndex) {
        Log-Msg -Message "  [!] Adjusting StarUI Free Lanes Patch priority order..." -Level "WARN" -ForegroundColor Yellow
        $patchObj = $FullModListOrder[$patchIndex]
        $FullModListOrder.RemoveAt($patchIndex)
        
        $starUIIndex = -1
        for ($i = 0; $i -lt $FullModListOrder.Count; $i++) {
            if ($FullModListOrder[$i].Name -eq "StarUI Inventory") { $starUIIndex = $i; break }
        }
        $FullModListOrder.Insert($starUIIndex + 1, $patchObj)
    }

    if (-not $IsSoftLaunch) {
        ($FullModListOrder | ForEach-Object { "$($_.Prefix)$($_.Name)" }) | Out-File -FilePath $ModListFile -Encoding utf8
    }

    # ----------------------------------------------------
    # 6. Read & Harvest Plugins
    # ----------------------------------------------------
    Log-Msg -Message "[6/8] Harvesting plugins from enabled mod folders..." -Level "INFO" -ForegroundColor Blue

    $PluginsFile = Join-Path -Path $ProfilePath -ChildPath "plugins.txt"
    $LoadOrderFile = Join-Path -Path $ProfilePath -ChildPath "loadorder.txt"
    if (-not (Test-Path $PluginsFile)) { $PluginsFile = Join-Path -Path $ProfilePath -ChildPath "loadorder.txt" }

    $ExistingPlugins = if (Test-Path $PluginsFile) { Get-Content -Path $PluginsFile | Where-Object { $_ -notmatch '^\s*#' -and $_.Trim() -ne '' } } else { @() }
    $ExistingPlugins | Out-File -FilePath $LoadOrderBeforeLog -Encoding utf8

    $DiscoveredPlugins = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($p in $ExistingPlugins) {
        $cleanP = $p.TrimStart('*')
        if ($cleanP) { [void]$DiscoveredPlugins.Add($cleanP) }
    }

    foreach ($modItem in $FullModListOrder) {
        if ($modItem.Prefix -eq "+") {
            $targetFolder = Join-Path $ModsDir $modItem.Name
            if (Test-Path $targetFolder) {
                Get-ChildItem -Path "$targetFolder\*" -Include *.esm, *.esp, *.esl -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
                    [void]$DiscoveredPlugins.Add($_.Name)
                }
            }
        }
    }

    # ----------------------------------------------------
    # 7. Categorized Smart Sorting Engine & Optional LOOT Integration
    # ----------------------------------------------------
    Log-Msg -Message "[7/8] Applying Load Order Sorting Logic..." -Level "INFO" -ForegroundColor Blue

    $LootRanSuccessfully = $false

    if ($EnableLOOT) {
        $PossibleLootPaths = @(
            "C:\Program Files\LOOT\lootcli.exe",
            "C:\LOOT\lootcli.exe",
            "D:\LOOT\lootcli.exe"
        )
        $LootExe = $PossibleLootPaths | Where-Object { Test-Path $_ } | Select-Object -First 1

        if ($LootExe) {
            try {
                Log-Msg -Message "  [LOOT] Executing LOOT CLI sorting for Starfield..." -Level "INFO" -ForegroundColor Cyan
                & $LootExe --game="Starfield" --game-path="$GameDir"
                $LootRanSuccessfully = $true
                Log-Msg -Message "  [LOOT] LOOT execution finished." -Level "INFO" -ForegroundColor Green
            } catch {
                Log-Msg -Message "  [!] LOOT CLI encountered an error. Falling back to internal sorter..." -Level "WARN" -ForegroundColor Red
            }
        } else {
            Log-Msg -Message "  [!] lootcli.exe not found in standard installation paths. Skipping LOOT and using internal sorter..." -Level "WARN" -ForegroundColor Yellow
        }
    }

    if (-not $LootRanSuccessfully) {
        $BaseGameMasters = @("Starfield.esm", "Constellation.esm", "OldMars.esm", "ShatteredSpace.esm")
        $CommunityFrameworks = @("StarfieldCommunityPatch.esm")

        if ($CustomRules -and $CustomRules.PriorityPlugins) {
            foreach ($pName in $CustomRules.PriorityPlugins) {
                if (-not ($CommunityFrameworks -contains $pName)) {
                    $CommunityFrameworks += $pName
                }
            }
        }

        $SortedBase = @(); $SortedFrameworks = @(); $SortedUI = @(); $SortedOtherESM = @(); $SortedESP = @(); $SortedPatches = @()

        foreach ($plugin in $DiscoveredPlugins) {
            $cat = if ($PluginCategoryMap.ContainsKey($plugin)) { $PluginCategoryMap[$plugin] } else { "" }

            if ($BaseGameMasters -contains $plugin) { continue }
            elseif ($CommunityFrameworks -contains $plugin) { $SortedFrameworks += $plugin }
            elseif ($cat -match "User Interface|UI|HUD" -or $plugin -like "*UI*" -or $plugin -like "*HUD*") { $SortedUI += $plugin }
            elseif ($cat -match "Bug Fixes|Patches" -or $plugin -like "*Patch*" -or $plugin -like "*Fix*") { $SortedPatches += $plugin }
            elseif ($plugin.EndsWith(".esm", [System.StringComparison]::OrdinalIgnoreCase)) { $SortedOtherESM += $plugin }
            else { $SortedESP += $plugin }
        }

        foreach ($bm in $BaseGameMasters) {
            if ($DiscoveredPlugins.Contains($bm)) { $SortedBase += $bm }
        }

        $FullSortedList = $SortedBase + $SortedFrameworks + ($SortedUI | Sort-Object) + ($SortedOtherESM | Sort-Object) + ($SortedESP | Sort-Object) + ($SortedPatches | Sort-Object)
        $FormattedLoadOrder = $FullSortedList | ForEach-Object { "*$_" }

        # Always save the outcome to the local log for previewing
        $FormattedLoadOrder | Out-File -FilePath $LoadOrderAfterLog -Encoding utf8

        if (-not $IsSoftLaunch) {
            $FormattedLoadOrder | Out-File -FilePath $PluginsFile -Encoding utf8
            if (Test-Path $LoadOrderFile) {
                $FormattedLoadOrder | Out-File -FilePath $LoadOrderFile -Encoding utf8
            } else {
                $FormattedLoadOrder | Out-File -FilePath (Join-Path -Path $ProfilePath -ChildPath "loadorder.txt") -Encoding utf8
            }
        }
    }

    # ----------------------------------------------------
    # 8. Output Logs & Launch Menu Prompts
    # ----------------------------------------------------
    Log-Msg -Message "[8/8] Finishing up..." -Level "INFO" -ForegroundColor Blue

    if ($IsSoftLaunch) {
        Write-Host "`n========================= SOFT LAUNCH PREVIEW =========================" -ForegroundColor Yellow
        Write-Host "  [!] DRY RUN COMPLETE: Profile files were NOT overwritten." -ForegroundColor Yellow
        Write-Host "  [+] Preview calculated load order in: load order after.txt" -ForegroundColor Green
        Write-Host "  [+] Preview installed mods in:         installed mods list.txt" -ForegroundColor Green
        Write-Host "  [+] Preview loose files in:            loose files mods sorted.txt" -ForegroundColor Green
        Write-Host "=======================================================================" -ForegroundColor Yellow
    } else {
        Log-Msg -Message "Successfully updated plugins.txt, loadorder.txt, and modlist.txt instantly!" -Level "INFO" -ForegroundColor Green
    }

    Write-Host "`n===================================================================================================" -ForegroundColor Red
    Write-Host "SCRIPTING IS STABILIZED VIA Google Gemini AI" -ForegroundColor Blue

    $response = Read-Host "Would you like to see my other mods on Nexus? (Y/N)"
    if ($response -eq 'Y' -or $response -eq 'y') {
        Write-Host "Fly Off!" -ForegroundColor Cyan
        Start-Sleep -Seconds 1
        Start-Process "https://www.nexusmods.com/profile/kimmidontcare"
    } else {
        Write-Host "Awww, well okay...later then space cowboy..or cowgirl..or whateva, we don't judge xD" -ForegroundColor Yellow
        Start-Sleep -Seconds 1
    }

    Write-Host ""
    $debugChoice = Read-Host "Would you like to open the DEBUG Manager? (Y/N)"
    if ($debugChoice -eq 'Y' -or $debugChoice -eq 'y') {
        if (Test-Path $DebugManagerScript) {
            Start-Process powershell.exe -ArgumentList "-File `"$DebugManagerScript`""
        } else {
            Write-Host "DEBUG Manager script not found at $DebugManagerScript" -ForegroundColor Red
            Start-Sleep -Seconds 2
        }
    }

    exit
} catch {
    # ----------------------------------------------------
    # Global Crash Handler -> Trigger UhOh.ps1
    # ----------------------------------------------------
    Log-Msg -Message "CRASH DETECTED: $($_.Exception.Message)" -Level "FATAL" -NoConsole
    Log-Msg -Message "Script Stack Trace: $($_.ScriptStackTrace)" -Level "FATAL" -NoConsole

    if (Test-Path $UhOhScript) {
        Start-Process powershell.exe -ArgumentList "-File `"$UhOhScript`""
    } else {
        Write-Host "`n[CRITICAL ERROR] $($_.Exception.Message)" -ForegroundColor Red
        Read-Host "Press Enter to exit..."
    }
    exit
}